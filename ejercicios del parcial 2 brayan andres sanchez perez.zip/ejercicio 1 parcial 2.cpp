/*ejercicio 1 del parcial realizado por brayan andres sanchez
ver 5.11 c++ 17/10/2022
1-. Implementar un programa recursivo que imprima los d�gitos de un n�mero natural n, 
le�do por teclado y mayor de 10000, en orden inverso. Por ejemplo, para n=10000 la salida deber�a ser 00001.  */

#include<stdio.h>
#include<string.h>
#include<locale.h>
#include<windows.h>


void invertir(char num[100],int largor);

int main(){
	setlocale(LC_ALL,"Spanish");
	char numero[100];
	printf("Ingrese el n�mero que desea invertir: ");
	gets(numero);
	printf("El n�mero invertido es: ");
	invertir(numero,strlen(numero)-1);
	printf("\n\n");
	system("pause");
	return 0;
}

void invertir(char num[100], int largor){
if(largor>=0){
printf("%c",num[largor]);	
invertir(num,largor-1);	
}	 
}
