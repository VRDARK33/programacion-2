/*ejercicio 4 del parcial realizado por brayan andres sanchez
ver 5.11 c++ 17/10/2022
4-. Escriba un programa que acepte como entrada desde teclado un n�mero natural mayor que 10.000 y d� 
como salida el resultado de sumar dos a dos los d�gitos que aparecen en posiciones sim�tricas respecto al d�gito central 
dentro del n�mero dado como entrada. Sin usar vectores y lectura del n�mero completo.  */

#include<iostream>
using namespace std;

void ingresarNum(int& n);
int tamNumero(int num);
//int potencia(int a, int b);
int calcularNum(int n, int i);
void sumar(int n);


int main(){
	int n;
	ingresarNum(n);
	sumar(n);
	return 0;
}

void ingresarNum(int& n){
	cout<<"ingrese un numero: ";
	cin>>n;
}

int tamNumero(int num){
	int contador = 0;
	while(num != 0){
		num = num/10;
		contador++;
	}
	return contador;
}



int calcularNum(int n, int i){
	int num;
	num =  n /(potencia(10,(i-1)));
	if(num == 0){
		num = -1;
	}else{
		num = num%10;
	}
	return num;
}

void sumar(int n){
	int longitud = tamNumero(n);
	int long2 = longitud;
	
	int suma;
	for(int i=1; i<= int(longitud/2);i++){
		suma =calcularNum(n,i) + calcularNum(n,long2);
		cout<< calcularNum(n, long2)<<"+"<<calcularNum(n,i) <<"=" <<suma<< " ";
		long2 --;
	}
	if(longitud%2 != 0){
		cout<<calcularNum(n,int(longitud/2)+1);
	}
}

